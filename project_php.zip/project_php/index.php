<?php
$usuario = "root";
$dbname = "sistema_clientes";
$host = "localhost";
$senha = "";
$porta = 3307; //definir apenas portas diferentes de 3306

try{
    $conexao = new PDO(
        "mysql:host=$host;port=$porta;dbname=$dbname;charset=utf8mb4",
        $usuario, $senha);
        echo "Conectado ao banco de dados!";
}catch(PDOException $erro){
    echo "Erro na conexão: ".$erro->getMessage();
    //echo "Erro na conexão: {$erro->getMessage()}";
}
$conexao = null; // fecha a conexão 
?>